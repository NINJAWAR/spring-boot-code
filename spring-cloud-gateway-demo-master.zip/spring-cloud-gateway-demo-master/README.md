# spring-cloud-gateway-demo

Code and articles to help you get started with [Spring Cloud Gateway][3].

For more information, see the accompanying pages [here][4].

## Authors

* [Ben Wilcock][1] – Spring Marketing, Pivotal.
* [Brian McClain][2] – Technical Marketing, Pivotal.

[1]: https://twitter.com/benbravo73
[2]: https://twitter.com/BrianMMcClain
[3]: https://spring.io/projects/spring-cloud-gateway
[4]: https://benwilcock.github.io/spring-cloud-gateway-demo
